﻿namespace FarmerAPI.Models;

public class AgroActionType
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;

    public ICollection<AgroAction>? AgroActions { get; set; }
}
