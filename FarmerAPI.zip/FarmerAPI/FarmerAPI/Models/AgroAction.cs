﻿namespace FarmerAPI.Models;

public class AgroAction
{
    public int Id { get; set; }
    public int FieldId { get; set; }
    public Field? Field { get; set; }

    public int ActionTypeId { get; set; }
    public AgroActionType? ActionType { get; set; }

    public DateTime Date { get; set; }
    public double? VolumeUsed { get; set; }
    public string? Result { get; set; }
}
