﻿namespace FarmerAPI.Models;

public class Harvest
{
    public int Id { get; set; }
    public int FieldId { get; set; }
    public Field? Field { get; set; }

    public DateTime Date { get; set; }
    public double Volume { get; set; }
    public string? Quality { get; set; }
}
