﻿namespace FarmerAPI.Models;

public class Season
{
    public int Id { get; set; }
    public int Year { get; set; }

    public int UserId { get; set; }
    public User? User { get; set; }
}
