﻿using FarmerAPI.Models;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace FarmerAPI.Data
{
    public class FarmerZDbContext : DbContext
    {
        public FarmerZDbContext(DbContextOptions<FarmerZDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Field> Fields { get; set; }
        public DbSet<CropType> CropTypes { get; set; }
        public DbSet<AgroAction> AgroActions { get; set; }
        public DbSet<AgroActionType> AgroActionTypes { get; set; }
        public DbSet<Harvest> Harvests { get; set; }
        public DbSet<Message> Messages { get; set; }
        public DbSet<Season> Seasons { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Message>()
                .HasOne(m => m.FromUser)
                .WithMany(u => u.SentMessages)
                .HasForeignKey(m => m.FromUserId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Message>()
                .HasOne(m => m.ToUser)
                .WithMany(u => u.ReceivedMessages)
                .HasForeignKey(m => m.ToUserId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
