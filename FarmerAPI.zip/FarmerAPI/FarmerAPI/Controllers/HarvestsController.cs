﻿using FarmerAPI.Data;
using FarmerAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace FarmerAPI.Controllers;

[Authorize(Roles = "Farmer")]
[ApiController]
[Route("api/[controller]")]
public class HarvestsController : ControllerBase
{
    private readonly FarmerZDbContext _context;
    public HarvestsController(FarmerZDbContext context) => _context = context;

    [HttpGet]
    public async Task<IEnumerable<Harvest>> Get()
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
        return await _context.Harvests
            .Include(h => h.Field)
            .Where(h => h.Field!.OwnerId == userId)
            .ToListAsync();
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Harvest>> Get(int id)
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
        var h = await _context.Harvests
            .Include(h => h.Field)
            .FirstOrDefaultAsync(h => h.Id == id && h.Field!.OwnerId == userId);

        return h == null ? NotFound() : h;
    }

    [HttpPost]
    public async Task<ActionResult<Harvest>> Post(Harvest h)
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
        var field = await _context.Fields.FindAsync(h.FieldId);
        if (field == null || field.OwnerId != userId)
            return BadRequest("Недопустимое поле");

        _context.Harvests.Add(h);
        await _context.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = h.Id }, h);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Put(int id, Harvest h)
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
        var field = await _context.Fields.FindAsync(h.FieldId);
        if (id != h.Id || field == null || field.OwnerId != userId)
            return BadRequest();

        _context.Entry(h).State = EntityState.Modified;
        await _context.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
        var h = await _context.Harvests
            .Include(h => h.Field)
            .FirstOrDefaultAsync(h => h.Id == id && h.Field!.OwnerId == userId);

        if (h == null) return NotFound();

        _context.Harvests.Remove(h);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}
