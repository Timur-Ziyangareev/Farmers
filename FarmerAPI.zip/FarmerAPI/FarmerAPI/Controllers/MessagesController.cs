﻿using FarmerAPI.Data;
using FarmerAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class MessagesController : ControllerBase
{
    private readonly FarmerZDbContext _context;
    public MessagesController(FarmerZDbContext context) => _context = context;

    [HttpGet]
    public async Task<IEnumerable<Message>> Get() =>
        await _context.Messages
            .Include(m => m.FromUser)
            .Include(m => m.ToUser)
            .ToListAsync();

    [HttpPost]
    public async Task<ActionResult<Message>> Post(Message m)
    {
        m.Timestamp = DateTime.Now;
        _context.Messages.Add(m);
        await _context.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = m.Id }, m);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var m = await _context.Messages.FindAsync(id);
        if (m == null) return NotFound();
        _context.Messages.Remove(m);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}
