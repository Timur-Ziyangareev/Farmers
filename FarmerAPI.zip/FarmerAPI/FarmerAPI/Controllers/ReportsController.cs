﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FarmerAPI.Data;
using FarmerAPI.Models;

namespace FarmerAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ReportsController : ControllerBase
{
    private readonly FarmerZDbContext _context;

    public ReportsController(FarmerZDbContext context)
    {
        _context = context;
    }

    // 1. Урожайность по культурам
    [HttpGet("yield-by-crop")]
    public async Task<IActionResult> GetYieldByCrop()
    {
        var result = await _context.Harvests
            .Include(h => h.Field)
            .ThenInclude(f => f.CropType)
            .GroupBy(h => h.Field.CropType!.Name)
            .Select(g => new
            {
                Crop = g.Key,
                TotalVolume = g.Sum(h => h.Volume),
                Count = g.Count()
            })
            .ToListAsync();

        return Ok(result);
    }

    // 2. Урожайность по сезонам
    [HttpGet("yield-by-season")]
    public async Task<IActionResult> GetYieldBySeason()
    {
        var result = await _context.Harvests
            .GroupBy(h => h.Date.Year)
            .Select(g => new
            {
                Year = g.Key,
                TotalVolume = g.Sum(h => h.Volume),
                Count = g.Count()
            })
            .OrderBy(r => r.Year)
            .ToListAsync();

        return Ok(result);
    }

    // 3. Эффективность агромероприятий
    [HttpGet("action-effectiveness")]
    public async Task<IActionResult> GetActionEffectiveness()
    {
        var result = await _context.AgroActions
            .Include(a => a.ActionType)
            .GroupBy(a => a.ActionType!.Name)
            .Select(g => new
            {
                Action = g.Key,
                TotalVolumeUsed = g.Sum(x => x.VolumeUsed ?? 0),
                Count = g.Count()
            })
            .ToListAsync();

        return Ok(result);
    }
}
