﻿using FarmerAPI.Data;
using FarmerAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace FarmerAPI.Controllers;

[Authorize(Roles = "Farmer")]
[ApiController]
[Route("api/[controller]")]
public class FieldsController : ControllerBase
{
    private readonly FarmerZDbContext _context;

    public FieldsController(FarmerZDbContext context)
    {
        _context = context;
    }

    // Получить только свои поля
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Field>>> GetFields()
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
        return await _context.Fields
            .Where(f => f.OwnerId == userId)
            .Include(f => f.CropType)
            .ToListAsync();
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Field>> GetField(int id)
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
        var field = await _context.Fields
            .Include(f => f.CropType)
            .FirstOrDefaultAsync(f => f.Id == id && f.OwnerId == userId);

        if (field == null)
            return NotFound();

        return field;
    }

    [HttpPost]
    public async Task<ActionResult<Field>> CreateField(Field field)
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
        field.OwnerId = userId;

        _context.Fields.Add(field);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetField), new { id = field.Id }, field);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateField(int id, Field field)
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
        if (id != field.Id || field.OwnerId != userId)
            return BadRequest();

        _context.Entry(field).State = EntityState.Modified;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteField(int id)
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
        var field = await _context.Fields.FirstOrDefaultAsync(f => f.Id == id && f.OwnerId == userId);
        if (field == null)
            return NotFound();

        _context.Fields.Remove(field);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}
