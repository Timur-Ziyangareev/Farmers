﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using FarmerAPI.Data;
using FarmerAPI.Models;

namespace FarmerAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly FarmerZDbContext _context;
    private readonly JwtSettings _jwtSettings;

    public AuthController(FarmerZDbContext context, IOptions<JwtSettings> jwtOptions)
    {
        _context = context;
        _jwtSettings = jwtOptions.Value;
    }

    // 🔑 Вход
    [HttpPost("login")]
    public IActionResult Login([FromBody] LoginDto dto)
    {
        var user = _context.Users
            .Where(u => u.Email == dto.Email)
            .FirstOrDefault();

        if (user == null)
            return Unauthorized("Email не найден");

        // Временно выведи в консоль
        Console.WriteLine($"FROM DB: {user.Password}");
        Console.WriteLine($"FROM DTO: {dto.Password}");

        if (user.Password.Trim() != dto.Password.Trim())
            return Unauthorized("Неверный пароль");

        var roleName = _context.Roles.FirstOrDefault(r => r.Id == user.RoleId)?.Name ?? "Farmer";

        var token = GenerateToken(user.Id.ToString(), user.Name, roleName);
        return Ok(new { token });
    }



    [HttpPost("register")]
    public IActionResult Register([FromBody] RegisterDto dto)
    {
        if (_context.Users.Any(u => u.Email == dto.Email))
            return BadRequest("Пользователь с таким Email уже существует");

        var role = _context.Roles.FirstOrDefault(r => r.Name == dto.Role);
        if (role == null)
            return BadRequest("Некорректная роль. Доступны: Farmer, Agronomist");

        var user = new User
        {
            Name = dto.Name,
            Email = dto.Email,
            Password = dto.Password, // Без хеширования — только для разработки!
            RoleId = role.Id
        };

        _context.Users.Add(user);
        _context.SaveChanges();

        return Ok("Регистрация успешна");
    }


    // JWT генерация
    private string GenerateToken(string userId, string name, string role)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, userId),
            new(ClaimTypes.Name, name),
            new(ClaimTypes.Role, role)
        };

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.Key));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer: _jwtSettings.Issuer,
            audience: _jwtSettings.Audience,
            claims: claims,
            expires: DateTime.Now.AddMinutes(_jwtSettings.DurationInMinutes),
            signingCredentials: creds
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
