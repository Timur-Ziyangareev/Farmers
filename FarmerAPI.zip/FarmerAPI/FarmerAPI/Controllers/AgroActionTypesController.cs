﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FarmerAPI.Data;
using FarmerAPI.Models;

namespace FarmerAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AgroActionTypesController : ControllerBase
{
    private readonly FarmerZDbContext _context;
    public AgroActionTypesController(FarmerZDbContext context) => _context = context;

    [HttpGet]
    public async Task<IEnumerable<AgroActionType>> Get() =>
        await _context.AgroActionTypes.ToListAsync();

    [HttpGet("{id}")]
    public async Task<ActionResult<AgroActionType>> Get(int id)
    {
        var item = await _context.AgroActionTypes.FindAsync(id);
        return item == null ? NotFound() : item;
    }

    [HttpPost]
    public async Task<ActionResult<AgroActionType>> Post(AgroActionType a)
    {
        _context.AgroActionTypes.Add(a);
        await _context.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = a.Id }, a);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Put(int id, AgroActionType a)
    {
        if (id != a.Id) return BadRequest();
        _context.Entry(a).State = EntityState.Modified;
        await _context.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var item = await _context.AgroActionTypes.FindAsync(id);
        if (item == null) return NotFound();
        _context.AgroActionTypes.Remove(item);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}
