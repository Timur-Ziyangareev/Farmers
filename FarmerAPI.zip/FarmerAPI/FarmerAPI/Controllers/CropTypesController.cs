﻿using FarmerAPI.Data;
using FarmerAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
[Authorize(Roles = "Admin")]
[ApiController]
[Route("api/[controller]")]
public class CropTypesController : ControllerBase
{
    private readonly FarmerZDbContext _context;
    public CropTypesController(FarmerZDbContext context) => _context = context;

    [HttpGet] public async Task<IEnumerable<CropType>> Get() => await _context.CropTypes.ToListAsync();

    [HttpPost]
    public async Task<ActionResult<CropType>> Post(CropType cropType)
    {
        _context.CropTypes.Add(cropType);
        await _context.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = cropType.Id }, cropType);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Put(int id, CropType cropType)
    {
        if (id != cropType.Id) return BadRequest();
        _context.Entry(cropType).State = EntityState.Modified;
        await _context.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var c = await _context.CropTypes.FindAsync(id);
        if (c == null) return NotFound();
        _context.CropTypes.Remove(c);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}
