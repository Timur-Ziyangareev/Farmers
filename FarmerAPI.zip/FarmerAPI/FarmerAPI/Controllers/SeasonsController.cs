﻿using FarmerAPI.Data;
using FarmerAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class SeasonsController : ControllerBase
{
    private readonly FarmerZDbContext _context;
    public SeasonsController(FarmerZDbContext context) => _context = context;

    [HttpGet]
    public async Task<IEnumerable<Season>> Get() =>
        await _context.Seasons.Include(s => s.User).ToListAsync();

    [HttpPost]
    public async Task<ActionResult<Season>> Post(Season s)
    {
        _context.Seasons.Add(s);
        await _context.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = s.Id }, s);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var s = await _context.Seasons.FindAsync(id);
        if (s == null) return NotFound();
        _context.Seasons.Remove(s);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}
