﻿using FarmerAPI.Data;
using FarmerAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FarmerAPI.Controllers;

[Authorize(Roles = "Agronomist")]
[ApiController]
[Route("api/[controller]")]
public class AgroActionsController : ControllerBase
{
    private readonly FarmerZDbContext _context;
    public AgroActionsController(FarmerZDbContext context) => _context = context;

    [HttpGet]
    public async Task<IEnumerable<AgroAction>> Get() =>
        await _context.AgroActions
            .Include(a => a.Field)
            .ThenInclude(f => f.CropType)
            .Include(a => a.ActionType)
            .ToListAsync();

    [HttpGet("{id}")]
    public async Task<ActionResult<AgroAction>> Get(int id)
    {
        var item = await _context.AgroActions
            .Include(a => a.Field)
            .Include(a => a.ActionType)
            .FirstOrDefaultAsync(a => a.Id == id);

        return item == null ? NotFound() : item;
    }

    [HttpPost]
    public async Task<ActionResult<AgroAction>> Post(AgroAction a)
    {
        _context.AgroActions.Add(a);
        await _context.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = a.Id }, a);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Put(int id, AgroAction a)
    {
        if (id != a.Id) return BadRequest();
        _context.Entry(a).State = EntityState.Modified;
        await _context.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var a = await _context.AgroActions.FindAsync(id);
        if (a == null) return NotFound();
        _context.AgroActions.Remove(a);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}
