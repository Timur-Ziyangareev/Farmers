﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using System.Security.Claims;

namespace FarmerAPI.Hubs;

[Authorize] // Только для авторизованных пользователей
public class MessageHub : Hub
{
    // Сопоставление подключений и пользователей
    private static readonly Dictionary<string, string> _connections = new();

    public override Task OnConnectedAsync()
    {
        string userId = Context.User?.FindFirstValue(ClaimTypes.NameIdentifier) ?? "unknown";
        string connectionId = Context.ConnectionId;

        if (!_connections.ContainsKey(userId))
        {
            _connections[userId] = connectionId;
        }

        Console.WriteLine($"🔗 Connected: userId={userId}, conn={connectionId}");
        return base.OnConnectedAsync();
    }

    public override Task OnDisconnectedAsync(Exception? exception)
    {
        var userId = Context.User?.FindFirstValue(ClaimTypes.NameIdentifier);
        if (userId != null && _connections.ContainsKey(userId))
        {
            _connections.Remove(userId);
        }

        Console.WriteLine($"❌ Disconnected: userId={userId}");
        return base.OnDisconnectedAsync(exception);
    }

    // Метод для отправки сообщений между пользователями
    public async Task SendMessage(string toUserId, string text)
    {
        string fromUserId = Context.User?.FindFirstValue(ClaimTypes.NameIdentifier) ?? "unknown";

        if (_connections.TryGetValue(toUserId, out string toConnectionId))
        {
            await Clients.Client(toConnectionId).SendAsync("ReceiveMessage", fromUserId, text);
        }

        // Также можно сделать сохранение сообщения в БД, если подключён FarmerZDbContext
    }
}
