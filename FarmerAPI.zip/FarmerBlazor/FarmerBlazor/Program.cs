﻿using FarmerBlazor.Components;

var builder = WebApplication.CreateBuilder(args);

// Добавляем Razor-компоненты и интерактивность
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// Сервисы для хранения токена и работы с API
builder.Services.AddSingleton<TokenStorage>();
builder.Services.AddTransient<AuthorizationMessageHandler>();

// HttpClient с базовым адресом и авторизацией
builder.Services.AddHttpClient("FarmerAPI", client =>
{
    client.BaseAddress = new Uri("https://localhost:7251/"); // ← Убедись, что порт верный
}).AddHttpMessageHandler<AuthorizationMessageHandler>();

// 👇 ЭТО ОБЯЗАТЕЛЬНО
builder.Services.AddScoped(sp =>
    sp.GetRequiredService<IHttpClientFactory>().CreateClient("FarmerAPI"));

builder.Services.AddScoped<AuthService>();
builder.Services.AddScoped<UserSessionService>();

var app = builder.Build();

// Обработка ошибок
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();

// Настройка маршрутов Razor-компонентов
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
