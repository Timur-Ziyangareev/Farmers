﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

public class UserSessionService
{
    private readonly TokenStorage _tokenStorage;

    public UserSessionService(TokenStorage tokenStorage)
    {
        _tokenStorage = tokenStorage;
    }

    public string? Token => _tokenStorage.Token;

    public ClaimsPrincipal? CurrentUser
    {
        get
        {
            if (string.IsNullOrEmpty(Token)) return null;

            var handler = new JwtSecurityTokenHandler();
            var jwtToken = handler.ReadJwtToken(Token);
            var identity = new ClaimsIdentity(jwtToken.Claims, "jwt");
            return new ClaimsPrincipal(identity);
        }
    }

    public string? Role =>
        CurrentUser?.FindFirst(ClaimTypes.Role)?.Value;

    public string? UserEmail =>
        CurrentUser?.FindFirst(ClaimTypes.Email)?.Value;

    public int UserId =>
        int.TryParse(CurrentUser?.FindFirst(ClaimTypes.NameIdentifier)?.Value, out var id) ? id : 0;

    public bool IsInRole(string roleName) =>
        Role == roleName;
}
