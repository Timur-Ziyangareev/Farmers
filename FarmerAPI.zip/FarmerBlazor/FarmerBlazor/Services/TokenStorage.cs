﻿public class TokenStorage
{
    public string? Token { get; set; }
}
