﻿
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using static System.Net.WebRequestMethods;

public class AuthService
{
    private readonly IHttpClientFactory _clientFactory;
    private readonly TokenStorage _tokenStorage;

    public AuthService(IHttpClientFactory clientFactory, TokenStorage tokenStorage)
    {
        _clientFactory = clientFactory;
        _tokenStorage = tokenStorage;
    }

    public async Task<bool> LoginAsync(string email, string password)
    {
        var client = _clientFactory.CreateClient("FarmerAPI");
        var response = await client.PostAsJsonAsync("api/Auth/login", new
        {
            Email = email,
            Password = password
        });

        if (response.IsSuccessStatusCode)
        {
            var result = await response.Content.ReadFromJsonAsync<TokenResponse>();
            _tokenStorage.Token = result?.Token;
            return true;
        }

        return false;
    }

    public void Logout()
    {
        _tokenStorage.Token = null;
    }

    private class TokenResponse
    {
        public string Token { get; set; } = "";
    }
}
